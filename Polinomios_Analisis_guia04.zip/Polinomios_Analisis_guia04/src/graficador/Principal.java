/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graficador;

/**
 *
 * @author Kevin Figueroa (...Rony)
 */
  
public class Principal
{
        public static void main(String args[])  {
            // crea objeto JFrame
            myFrame aplicacion = new myFrame();
            aplicacion.show();
	} // fin de main 
} 
