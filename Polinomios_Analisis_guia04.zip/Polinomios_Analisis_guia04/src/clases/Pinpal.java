package clases;
import GUI.Principal_frm;

/**
 *
 * @author kevin Figueroa
 */
public class Pinpal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

Principal_frm main = new Principal_frm();
main.show();


    }



}
